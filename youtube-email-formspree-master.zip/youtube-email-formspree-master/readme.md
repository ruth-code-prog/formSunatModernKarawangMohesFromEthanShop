# Send email without server code

Hello, I created this repo for youtube tutorial video. This code allows you to send email without any server code using formspree.io

[Go to Formspree](https://formspree.io/)

How to install:

1. Register for formspree new account, create new form and get the formspree url
2. go to index.html
3. go to form code

```
<form id="contact-form" action="your_formspree_url" method="POST">
```

4. Change the action value to your formspree url and

Thank you

Follow me on instagram : [@birunidev](https://instagram.com/birunidev)
Subscribe my youtube channel : [Biruni Dev](https://youtube.com/c/BiruniDev)
